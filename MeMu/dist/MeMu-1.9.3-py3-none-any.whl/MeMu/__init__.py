
from .MeMu import Memu

__version__ = "1.9.3"
